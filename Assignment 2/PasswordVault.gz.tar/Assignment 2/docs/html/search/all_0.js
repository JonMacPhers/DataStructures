var searchData=
[
  ['deletedatafromlist',['deleteDataFromList',['../LinkedListAPI_8h.html#ae1a14b22705ddc68f907e6732f4d0843',1,'LinkedListAPI.c']]],
  ['deletelist',['deleteList',['../LinkedListAPI_8h.html#abc18ab05ec8bd1b4ea085d5b30baf536',1,'LinkedListAPI.c']]]
];
