var searchData=
[
  ['node',['Node',['../LinkedListAPI_8h.html#a6e6fe3ff3f9c8838790f110122178136',1,'LinkedListAPI.h']]]
];
